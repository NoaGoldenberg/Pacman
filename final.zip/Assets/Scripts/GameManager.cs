using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
using TMPro;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public Ghost[] ghosts;
    public UIManager uiManager;
    private Fruits fruits;
    private Pacman pacman;
    public Transform pellets;
    public TextMeshProUGUI ScoreText;
    public TextMeshProUGUI HighScoreText;
    private int PowerPellet_duration = 15;
    private int ghostMultiplier = 1;

    public int Score;
    public int HighScore;
    public int Lives;

    public bool sound = true;
    public AudioSource siren;
    public AudioSource munch1;
    public AudioSource munch2;

    private int pelletCount = 0;
    public bool isInvincible = false;
    

    public static GameManager instance; 

    private void Awake()
    {
        if(instance!=null) 
        {
            Debug.LogError("Singleton violation");
            return;
        }
        instance = this;
        pacman = GetComponent<Pacman>();
        fruits = GameObject.Find("fruits").GetComponent<Fruits>();
        
   
    }


    void Start()
    {
        siren.Play();
        StartGame();
    }

    private void StartGame()
    {
        SetScore(0);
        Lives = 3;
    }

    void Update()
    {
        if (Lives <= 0) {
            StartGame();
        }

         UpdateScoreUI();
    }


    private void SetScore(int score)
    {
        Score = score;
        if (Score > HighScore)
        {
            HighScore = score;
        }
    }

    public void PlayAudio()
    {
        if(sound)
        {
            siren.Play();
        }
    }

    public void MuteAudio()
    {
        
            siren.Pause();
    }

    private void UpdateScoreUI()
    {
        ScoreText.text = "Score: " + Score;
        HighScoreText.text = "High Score: " + HighScore;
    }


    public void EatPellet(GameObject pellet, int add_score)
    {
        if (sound)
        {
            munch1.Play();
        }
        pellet.gameObject.SetActive(false);

        SetScore(Score + add_score);

        if (!HasMorePellets())
        {
            Win();
        }
        pelletCount++; // Increment the pellet count

        // Check if Pacman has eaten more than 70 pellets
        if (pelletCount == 10)
        {
            fruits.Spawncherry();
        }

        if (pelletCount == 170)
        {
            fruits.SpawnStrawberry();
             
        }
    }


     public void EatPowerPellet(GameObject PowerPellet)
     {
        if (sound)
        {
            munch2.Play();
        }
        
        for (int i = 0; i < ghosts.Length; i++) {
            ghosts[i].frightened.Enable(PowerPellet_duration);
        }

        EatPellet(PowerPellet, 50);
        CancelInvoke(nameof(ResetGhostMultiplier));
        Invoke(nameof(ResetGhostMultiplier), PowerPellet_duration);

     }

     public void EatAGhost(Ghost ghost)
     {
         SetScore(Score + 200);
         ghostMultiplier++;
     }


    public void PacmanEaten()
    {
        Lives = Lives - 1;
       if (Lives > 0) {

            uiManager.reduce_live();
            for (int i = 0; i < ghosts.Length; i++) {
            ghosts[i].gameObject.SetActive(false);
            }
            pacman.Die_Anim();
            Invoke(nameof(NewRound), 3f);
        } else {
            GameOver();
            pacman.Die_Anim();
        }

    }

    private void NewRound()
    {
        for (int i = 0; i < ghosts.Length; i++) {
            ghosts[i].ResetState();
        } 
        pacman.Reset();
    }

    private void GameOver()
    {
        uiManager.GameOver();

        for (int i = 0; i < ghosts.Length; i++) {
            ghosts[i].gameObject.SetActive(false);
        }
        Invoke(nameof(Reset), 3f);
        
    }

    private void Win()
    {
        Pause();
        uiManager.Win_panel();
        

    }

    private void Reset()
    {
        uiManager.NewGameUI();
        pelletCount = 0;

        foreach (Transform pellet in pellets ) {
            pellet.gameObject.SetActive(true);
        }
        for (int i = 0; i < ghosts.Length; i++) {
            ghosts[i].ResetState();
        } 
        pacman.Reset();
        fruits.ResetFruits();
        
    }


    private bool HasMorePellets()
    {
        foreach (Transform pellet in pellets)
        {
            if (pellet.gameObject.activeSelf) {
                return true;
            }
        }

        return false;
    }


    public void Pause()
    {
        Time.timeScale = 0f; // Stop time to pause the game
        pacman.enabled = false;
    }


    public void Resume()
    {
        Time.timeScale = 1f; // Resume time to unpause the game
        pacman.enabled = true;
    }

    private void ResetGhostMultiplier()
    {
        ghostMultiplier = 1;
    }

   public void OnEatStrawberry()
   {
        SetScore(Score + 300);
   }
   public void OnEatCherry()
   {
        SetScore(Score + 100);
   }

   public void OnEatApple()
   {
        SetScore(Score + 500);
   }
}
    

