using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MuteButton : MonoBehaviour
{

    public UIManager uiManager;

    public void OnPlayButtonClick()
    {
        GameManager.instance.sound =  true;
        GameManager.instance.PlayAudio();
        uiManager.GetComponent<UIManager>().PlayAudio();
    }
}

