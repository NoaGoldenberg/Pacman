using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResumeButton : MonoBehaviour
{
    public UIManager uiManager;
    // Start is called before the first frame update
    public void OnPlayButtonClick()
    {
        GameManager.instance.Resume();
        GameManager.instance.PlayAudio();
        uiManager.GetComponent<UIManager>().Resume();
    }
}
