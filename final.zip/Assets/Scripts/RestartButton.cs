using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RestartButton : MonoBehaviour
{
public UIManager uiManager;
   public void OnPlayButtonClick()
    {
        GameManager.instance.Resume();
        GameManager.instance.PlayAudio();
        SceneManager.LoadScene("Start");
    }
}
