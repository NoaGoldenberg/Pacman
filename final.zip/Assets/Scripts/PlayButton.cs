using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayButton : MonoBehaviour
{

    public UIManager uiManager;
    // Start is called before the first frame update
    public void OnPlayButtonClick()
    {
        GameManager.instance.sound = false;
        GameManager.instance.MuteAudio();
        uiManager.GetComponent<UIManager>().MuteAudio();
    }
}
