using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Pacman : MonoBehaviour
{
    private Movement movement;
    public Animator animator;
    private int animationValue;
    private SpriteRenderer spriteRenderer;
    int InvinvibilityDuration = 8;
    private Fruits fruits;
    private CircleCollider2D collider;


    


    private void Awake()
    {
        movement = GetComponent<Movement>();
        animator = GetComponent<Animator>();
        // animator.SetBool("Moving", true);
        animator.SetBool("pacman_is_alive", true);
        spriteRenderer = GetComponent<SpriteRenderer>();
        fruits = GameObject.Find("fruits").GetComponent<Fruits>();
        collider = GetComponent<CircleCollider2D>(); // Change this line to get a CircleCollider2D
        
    }
        
    

    public void Reset()
    {
        // pacman_death.enabled = false;
        movement.Reset();
        movement.ResumeMovement();
        animator.SetBool("pacman_is_alive", true);
        Debug.Log("settingBool");
    }
  

    void Update()
    {
        
        // Get user input
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            animationValue = 2;
            movement.SetDirection(Vector2.up);
            

        }
        else if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            animationValue = 3;
            movement.SetDirection(Vector2.down);
            
        }
        else if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            animationValue = 1;
            movement.SetDirection(Vector2.left);
           
        }
        else if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            animationValue = 0;
            movement.SetDirection(Vector2.right);
            
        }
        
    }
    
     public void Anim()
    {
        // animator.SetBool("Moving", true);
        animator.SetInteger("direction",animationValue);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("pellet"))
        {
            GameManager.instance.EatPellet(other.gameObject, 10);  
        }

        else if (other.gameObject.layer == LayerMask.NameToLayer("PowerPellet"))
        {
            GameManager.instance.EatPowerPellet(other.gameObject);  
        }

        else if (other.gameObject.layer == LayerMask.NameToLayer("InvinciblePill"))
        {
            MakePacmanInvincible();
            other.gameObject.SetActive(false);
        }

        else if (other.gameObject.tag == "Strawberry")
        {
            fruits.DeActivate_strawberry();
            
        }

        else if (other.gameObject.tag == "Cherry")
        {
            fruits.DeActivate_cherry();
            
        }
    }

    public void Die_Anim()
    {
        // animator.SetBool("Moving", false);
        animator.SetBool("pacman_is_alive", false);
        movement.FreezeMovement();
        // Invoke(nameof(Disable), 2.0f);
    }

    // private void Disable()
    // {
    //     gameObject.SetActive(false);
    // }


    
    private void MakePacmanInvincible()
    {

        // spriteRenderer.enabled = false;
        GameManager.instance.isInvincible = true;
        StartCoroutine(InvincibilityTimer());
        DisableGhostCollision();
        transform.localScale = new Vector3(0.5f, 0.5f, 1f);
        movement.speedmult = 1.5f;
        collider.radius = 1.0f;
    }

    private IEnumerator InvincibilityTimer()
    {
        yield return new WaitForSeconds(InvinvibilityDuration); 
        GameManager.instance.isInvincible = false;
        EnableGhostCollision();
        movement.speedmult = 1.0f;
        transform.localScale = Vector3.one;
        collider.radius = 0.5f;
    }


    private void DisableGhostCollision()
        {
            int pacmanLayer = LayerMask.NameToLayer("pacman");
            int ghostLayer = LayerMask.NameToLayer("ghost");
            Physics2D.IgnoreLayerCollision(pacmanLayer, ghostLayer, true);
        }

        private void EnableGhostCollision()
        {
            int pacmanLayer = LayerMask.NameToLayer("pacman");
            int ghostLayer = LayerMask.NameToLayer("ghost");
            Physics2D.IgnoreLayerCollision(pacmanLayer, ghostLayer, false);
        }
   

}

