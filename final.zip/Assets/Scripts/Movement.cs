using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    
    public float speed = 8.0f;
    public float speedmult = 1.0f;

    public new Rigidbody2D rigidbody { get; private set;}
    public Vector3 startPosition {get; private set;}

    public Vector2 initialdirection;
    public Vector2 direction;
    public Vector2 nextDirection;
    private Pacman pacman;

    private bool isMovementAllowed = true;
    
    public LayerMask Obstacle; 
    
    private void Awake()
    {
        rigidbody = GetComponent<Rigidbody2D>();
        pacman = GetComponent<Pacman>();
        startPosition = transform.position;
        
    }

    private void Start()
    {
        Reset();
    }



    public void Reset()
    {
        direction = initialdirection;
        transform.position = startPosition;
        isMovementAllowed = true;
    }
   
    private void Update()
    {
        if (nextDirection != Vector2.zero && isMovementAllowed)
        {
            SetDirection(nextDirection);
        }

    }

    private void FixedUpdate()
    {
        if (isMovementAllowed) // Only move if movement is allowed
        {
            Vector2 position = rigidbody.position;
            Vector2 result = direction * speed * speedmult * Time.fixedDeltaTime;
            rigidbody.MovePosition(position + result);
        }
    }

    public void FreezeMovement()
        {
            isMovementAllowed = false;
        }

    
    public void ResumeMovement()
        {
            isMovementAllowed = true;
        }


    

   public void SetDirection(Vector2 newdirection, bool forced = false, int num = 0)
   {
        if (forced || CanMove(newdirection))
        {
            direction = newdirection;
            nextDirection = Vector2.zero;
        }
        else
        {
            nextDirection = newdirection;
        }
   }

   public bool CanMove(Vector2 newdirection)
   {
        RaycastHit2D hit = Physics2D.BoxCast(transform.position, Vector2.one * 0.75f, 0.0f, newdirection, 1.5f, Obstacle);
        if (hit.collider == null)
        {
            if(pacman)
            {
                pacman.Anim();
            }
            return true;
        }
        return false;
   }
}
