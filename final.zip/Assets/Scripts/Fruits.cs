using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fruits : MonoBehaviour
{
    public GameObject spawnPoint;
    public GameObject cherry;
    public GameObject strawberry;

    public UIManager uiManager;

    private void Awake()
    {
        uiManager = FindObjectOfType<UIManager>();
        if (uiManager == null)
        {
            Debug.LogError("UIManager not found in the scene.");
        }
        cherry.SetActive(false);
        strawberry.SetActive(false);

    }

    public void Spawncherry()
    {
        cherry.SetActive(true);  
        
    }

    public void SpawnStrawberry()
    {
        
        strawberry.SetActive(true); 
        
    }

    public void DeActivate_cherry()
    {
        cherry.SetActive(false);
        uiManager.Cherry_image();
    }

    public void DeActivate_strawberry()
    {
        strawberry.SetActive(false);
        uiManager.Strawberry_image();
    }
   
    public void ResetFruits()
    {
        if (strawberry.activeSelf)
        {
            strawberry.SetActive(false);
        }
        else if (cherry.activeSelf)
        {
            cherry.SetActive(false);
        }
    }

}
