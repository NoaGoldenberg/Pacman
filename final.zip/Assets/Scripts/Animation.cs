using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Animation : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;
    public float animationTime = 0.25f;
    public Sprite[] sprites;
    private int animationFrame;
    public bool loop = true;


    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }
    
    private void Start()
    {
        InvokeRepeating(nameof(Advance), animationTime, animationTime);
    }

    private void Advance()
    {
        if (!spriteRenderer.enabled) 
        {
            return;
        }
        animationFrame++;
        if (animationFrame >= sprites.Length) //maybe = loop
        {
            animationFrame = 0;
        }
            spriteRenderer.sprite = sprites[animationFrame];
    }

    private void OnEnable()
    {
        spriteRenderer.enabled = true;
    }

    private void OnDisable()
    {
        spriteRenderer.enabled = false;
    }
    

    public void Restart()
    {
        animationFrame = -1;

        Advance();
    }


}
