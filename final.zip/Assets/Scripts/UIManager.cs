using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public GameObject PausePanel;
    public GameObject winPanel;
    private bool GameIsPaused = false;
    private GameObject GameOverUI;
    private GameObject PauseMenuUI;
    public GameObject PauseButton;
    public GameObject ResumeButton;
    public GameObject PlayButton;
    public GameObject MuteButton;
    public GameObject Live1;
    public GameObject Live2;
    public GameObject Cherry;
    public GameObject Strawberry;
    public TextMeshProUGUI GameOverText;

    public GameObject[] powerPellets;
    public float blinkInterval = 0.5f;
    private bool isPelletVisible = true;

    // Call this method to start the blinking effect
    

	void Awake () {
        // Get panel object
        if (PausePanel == null) {
            Debug.LogError("PauseMenuPanel object not found.");
            return;
        }
        NewGameUI();
        
        
	}

    public void Pause()
    {   
        PausePanel.SetActive(true); 
        PauseButton.SetActive(false);
    }

    public void Resume()
    {   
        PausePanel.SetActive(false); 
        PauseButton.SetActive(true);
    }

    public void GameOver()
    {
        GameOverText.gameObject.SetActive(true);
    }

    public void NewGameUI()
    {
        winPanel.SetActive(false);
        PausePanel.SetActive(false); // Hide menu on start
        GameOverText.gameObject.SetActive(false);
        MuteButton.gameObject.SetActive(false);
        Strawberry.SetActive(false);
        Cherry.SetActive(false);
    }

    public void PlayAudio()
    {
        MuteButton.gameObject.SetActive(false);
        PlayButton.gameObject.SetActive(true);
    }

    public void MuteAudio()
    {
        MuteButton.gameObject.SetActive(true);
        PlayButton.gameObject.SetActive(false);
    }

    public void StartBlinking()
    {
        InvokeRepeating("TogglePowerPelletsVisibility", 0f, blinkInterval);
    }

    // Call this method to stop the blinking effect
    public void StopBlinking()
    {
        CancelInvoke("TogglePowerPelletsVisibility");
    }

    // Method to toggle the visibility of power pellets
    public void TogglePowerPelletsVisibility()
    {
        isPelletVisible = !isPelletVisible; // Toggle visibility
        foreach (GameObject pellet in powerPellets)
        {
            pellet.SetActive(isPelletVisible);
        }
    }


    public void reduce_live()
    {
        if (Live2.activeSelf) // Check if Live2 is active
        {
            Live2.SetActive(false); // If Live2 is active, deactivate it
        }
        else // If Live2 is not active, deactivate Live1
        {
            Live1.SetActive(false);
        }
    }

    public void Cherry_image()
    {
        Cherry.SetActive(true);
    }

    public void Strawberry_image()
    {
        Strawberry.SetActive(true);
    }

    public void Win_panel()
    {
        winPanel.SetActive(true);

    }
}