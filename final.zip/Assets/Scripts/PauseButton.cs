using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseButton : MonoBehaviour
{
    public UIManager uiManager;

    public void OnPlayButtonClick()
    {
        GameManager.instance.Pause();
        GameManager.instance.MuteAudio();
        uiManager.GetComponent<UIManager>().Pause();
    }
}
